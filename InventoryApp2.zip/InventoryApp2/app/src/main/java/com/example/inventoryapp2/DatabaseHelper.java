package com.example.inventoryapp2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;


    // User table
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";


    // Inventory table
    public static final String TABLE_INVENTORY = "inventory";
    public static final String COLUMN_ITEM_ID = "id";
    public static final String COLUMN_ITEM_NAME = "name";
    public static final String COLUMN_ITEM_QUANTITY = "quantity";
    public static final String COLUMN_ITEM_PRICE = "price";
    public static final String COLUMN_ITEM_CATEGORY = "category";


    // User settings table for notifications
    public static final String TABLE_SETTINGS = "settings";
    public static final String COLUMN_SETTING_ID = "id";
    public static final String COLUMN_NOTIFICATION_PHONE = "notification_phone";


    // Create table statements
    private static final String CREATE_TABLE_USERS = "CREATE TABLE " + TABLE_USERS + "("
            + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_USERNAME + " TEXT UNIQUE NOT NULL, "
            + COLUMN_PASSWORD + " TEXT NOT NULL);";

    private static final String CREATE_TABLE_INVENTORY = "CREATE TABLE " + TABLE_INVENTORY + "("
            + COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_ITEM_NAME + " TEXT NOT NULL, "
            + COLUMN_ITEM_QUANTITY + " INTEGER NOT NULL, "
            + COLUMN_ITEM_PRICE + " REAL NOT NULL, "
            + COLUMN_ITEM_CATEGORY + " TEXT);";

    private static final String CREATE_TABLE_SETTINGS = "CREATE TABLE " + TABLE_SETTINGS + "("
            + COLUMN_SETTING_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_NOTIFICATION_PHONE + " TEXT);";


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_INVENTORY);
        db.execSQL(CREATE_TABLE_SETTINGS);

        // Add a default admin user
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, "admin");
        values.put(COLUMN_PASSWORD, "admin123");
        db.insert(TABLE_USERS, null, values);


        // Add default empty setting
        ContentValues settingValues = new ContentValues();
        settingValues.put(COLUMN_NOTIFICATION_PHONE, "");
        db.insert(TABLE_SETTINGS, null, settingValues);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older tables if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SETTINGS);

        // Create tables again
        onCreate(db);
    }

    // User authentication methods
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = {COLUMN_USER_ID};
        String selection = COLUMN_USERNAME + " = ?" + " AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();

        cursor.close();
        db.close();

        return count > 0;
    }

    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password); // In production, use password hashing

        long result = db.insert(TABLE_USERS, null, values);
        db.close();

        return result != -1;
    }

    // Inventory CRUD operations
    public long addInventoryItem(String name, int quantity, double price, String category, Context context) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_ITEM_NAME, name);
        values.put(COLUMN_ITEM_QUANTITY, quantity);
        values.put(COLUMN_ITEM_PRICE, price);
        values.put(COLUMN_ITEM_CATEGORY, category);

        long id = db.insert(TABLE_INVENTORY, null, values);

        // Check if quantity is zero and send notification
        if (quantity == 0 && context != null) {
            String phoneNumber = getNotificationPhoneNumber();
            if (phoneNumber != null && !phoneNumber.isEmpty() &&
                    SmsNotificationUtils.checkSmsPermission(context)) {
                SmsNotificationUtils.sendLowStockNotification(context, phoneNumber, name);
            }
        }

        db.close();
        return id;
    }

    public Cursor getAllInventoryItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_INVENTORY, null, null, null, null, null, COLUMN_ITEM_NAME);
    }

    public boolean updateInventoryItem(int id, String name, int quantity, double price, String category, Context context) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_ITEM_NAME, name);
        values.put(COLUMN_ITEM_QUANTITY, quantity);
        values.put(COLUMN_ITEM_PRICE, price);
        values.put(COLUMN_ITEM_CATEGORY, category);

        int rowsAffected = db.update(TABLE_INVENTORY, values, COLUMN_ITEM_ID + " = ?",
                new String[]{String.valueOf(id)});

        // Check if quantity is zero and send notification
        if (quantity == 0 && context != null) {
            String phoneNumber = getNotificationPhoneNumber();
            if (phoneNumber != null && !phoneNumber.isEmpty() &&
                    SmsNotificationUtils.checkSmsPermission(context)) {
                SmsNotificationUtils.sendLowStockNotification(context, phoneNumber, name);
            }
        }

        db.close();
        return rowsAffected > 0;
    }

    public boolean deleteInventoryItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete(TABLE_INVENTORY, COLUMN_ITEM_ID + " = ?",
                new String[]{String.valueOf(id)});
        db.close();

        return rowsAffected > 0;
    }

    public String getNotificationPhoneNumber() {
        SQLiteDatabase db = this.getReadableDatabase();
        String phoneNumber = "";

        Cursor cursor = db.query(TABLE_SETTINGS, new String[]{COLUMN_NOTIFICATION_PHONE},
                null, null, null, null, null);

        if (cursor.moveToFirst()) {
            phoneNumber = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NOTIFICATION_PHONE));
        }
        cursor.close();
        db.close();

        return phoneNumber;
    }

    public boolean saveNotificationPhoneNumber(String phoneNumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NOTIFICATION_PHONE, phoneNumber);

        // Update the first row (there should be only one settings record)
        int rowsAffected = db.update(TABLE_SETTINGS, values, COLUMN_SETTING_ID + " = ?",
                new String[]{"1"});

        // If no rows affected (unlikely), insert new row
        if (rowsAffected == 0) {
            db.insert(TABLE_SETTINGS, null, values);
        }

        db.close();
        return true;
    }
}


