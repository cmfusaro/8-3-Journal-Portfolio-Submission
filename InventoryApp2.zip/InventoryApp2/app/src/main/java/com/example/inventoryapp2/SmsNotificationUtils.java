package com.example.inventoryapp2;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
public class SmsNotificationUtils {
    public static final int SMS_PERMISSION_REQUEST_CODE = 101;

    // Check if we have SMS permission
    public static boolean checkSmsPermission(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    // Request SMS permission
    public static void requestSmsPermission(Activity activity) {
        ActivityCompat.requestPermissions(
                activity,
                new String[]{Manifest.permission.SEND_SMS},
                SMS_PERMISSION_REQUEST_CODE
        );
    }

    // Send SMS notification
    public static void sendLowStockNotification(Context context, String phoneNumber, String itemName) {
        try {
            if (phoneNumber == null || phoneNumber.isEmpty()) {
                Toast.makeText(context, "No phone number has been added for notifications",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            SmsManager smsManager = context.getSystemService(SmsManager.class);
            String message = "INVENTORY ALERT: " + itemName + " is out of stock!";
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

            Toast.makeText(context, "SMS notification sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(context, "Failed to send SMS: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }
}

