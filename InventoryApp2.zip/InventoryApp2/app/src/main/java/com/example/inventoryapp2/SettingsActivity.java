package com.example.inventoryapp2;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SettingsActivity  extends AppCompatActivity {

    private EditText etPhoneNumber;
    private Button btnSaveSettings;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        databaseHelper = new DatabaseHelper(this);

        etPhoneNumber = findViewById(R.id.etPhoneNumber);
        btnSaveSettings = findViewById(R.id.btnSaveSettings);

        // Load current phone number
        String currentPhone = databaseHelper.getNotificationPhoneNumber();
        etPhoneNumber.setText(currentPhone);

        // Save button click listener
        btnSaveSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSettings();
            }
        });

        // Check for SMS permission
        if (!SmsNotificationUtils.checkSmsPermission(this)) {
            SmsNotificationUtils.requestSmsPermission(this);
        }
    }

    private void saveSettings() {
        String phoneNumber = etPhoneNumber.getText().toString().trim();

        if (databaseHelper.saveNotificationPhoneNumber(phoneNumber)) {
            Toast.makeText(this, "Settings saved successfully", Toast.LENGTH_SHORT).show();

            // If phone number is set, check for SMS permission
            if (!phoneNumber.isEmpty() && !SmsNotificationUtils.checkSmsPermission(this)) {
                SmsNotificationUtils.requestSmsPermission(this);
            }

            finish();
        } else {
            Toast.makeText(this, "Failed to save settings", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SmsNotificationUtils.SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied. Notifications won't be sent.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

}
