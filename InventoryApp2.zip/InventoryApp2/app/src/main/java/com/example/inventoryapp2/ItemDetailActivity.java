package com.example.inventoryapp2;

import static java.security.AccessController.getContext;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import com.example.inventoryapp2.DatabaseHelper;
import com.example.inventoryapp2.R;

public class ItemDetailActivity extends AppCompatActivity {
    private EditText etItemName, etItemQuantity, etItemPrice, etItemCategory;
    private Button btnUpdate;
    private DatabaseHelper databaseHelper;
    private int itemId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        databaseHelper = new DatabaseHelper(this);

        // Initialize views
        etItemName = findViewById(R.id.etItemName);
        etItemQuantity = findViewById(R.id.etItemQuantity);
        etItemPrice = findViewById(R.id.etItemPrice);
        etItemCategory = findViewById(R.id.etItemCategory);
        btnUpdate = findViewById(R.id.btnUpdate);

        // Get item details from intent
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            itemId = extras.getInt("ITEM_ID");
            etItemName.setText(extras.getString("ITEM_NAME"));
            etItemQuantity.setText(String.valueOf(extras.getInt("ITEM_QUANTITY")));
            etItemPrice.setText(String.format("%.2f", extras.getDouble("ITEM_PRICE")));
            etItemCategory.setText(extras.getString("ITEM_CATEGORY"));
        }

        // Update button click listener
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateItem();
            }
        });
    }

    private void updateItem() {
        String name = etItemName.getText().toString().trim();
        String quantityStr = etItemQuantity.getText().toString().trim();
        String priceStr = etItemPrice.getText().toString().trim();
        String category = etItemCategory.getText().toString().trim();

        // Validate input
        if (name.isEmpty() || quantityStr.isEmpty() || priceStr.isEmpty()) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int quantity = Integer.parseInt(quantityStr);
            double price = Double.parseDouble(priceStr);

            // Update item in database
            boolean success = databaseHelper.updateInventoryItem(itemId, name, quantity, price, category, this);
            if (success) {
                Toast.makeText(this, "Item updated successfully", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to update item", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid quantity or price", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.detail_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_delete) {
            confirmDelete();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void confirmDelete() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Item");
        builder.setMessage("Are you sure you want to delete this item?");
        builder.setPositiveButton("Delete", (dialog, which) -> {
            boolean success = databaseHelper.deleteInventoryItem(itemId);
            if (success) {
                Toast.makeText(this, "Item deleted successfully", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to delete item", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
}

