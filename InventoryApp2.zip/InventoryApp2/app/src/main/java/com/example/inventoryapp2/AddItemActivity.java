package com.example.inventoryapp2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {
    private EditText etItemName, etItemQuantity, etItemPrice, etItemCategory;
    private Button btnSave;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        databaseHelper = new DatabaseHelper(this);

        // Initialize views
        etItemName = findViewById(R.id.etItemName);
        etItemQuantity = findViewById(R.id.etItemQuantity);
        etItemPrice = findViewById(R.id.etItemPrice);
        etItemCategory = findViewById(R.id.etItemCategory);
        btnSave = findViewById(R.id.btnSave);

        // Save button click listener
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveItem();
            }
        });
    }

    private void saveItem() {
        String name = etItemName.getText().toString().trim();
        String quantityStr = etItemQuantity.getText().toString().trim();
        String priceStr = etItemPrice.getText().toString().trim();
        String category = etItemCategory.getText().toString().trim();

        // Validate input
        if (name.isEmpty() || quantityStr.isEmpty() || priceStr.isEmpty()) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int quantity = Integer.parseInt(quantityStr);
            double price = Double.parseDouble(priceStr);

            // Add item to database
            long id = databaseHelper.addInventoryItem(name, quantity, price, category, this);
            if (id != -1) {
                Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid quantity or price", Toast.LENGTH_SHORT).show();
        }
    }
}

